<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['detsuid']==0)) {
  header('location:logout.php');
  } else {

if(isset($_POST['submit']))
  {
  	$userid=$_SESSION['detsuid'];
    $name=$_POST['name'];
     $amount=$_POST['amount'];
     $description=$_POST['description'];
      $notedate=$_POST['notedate'];
    $query=mysqli_query($con, "insert into tbldonation(UserId,Name,Amount,Description,NoteDate) value('$userid','$name','$amount','$description','$notedate')");
if($query){
echo "<script>alert('Donation has been added');</script>";
echo "<script>window.location.href='manage-donation.php'</script>";
} else {
echo "<script>alert('Something went wrong. Please try again');</script>";

}
  
}
  ?>
  <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>श्री १००८ भगवान पार्श्वनाथ दिगंबर जिन मंदिर</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">
	
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<?php include_once('includes/header.php');?>
	<?php include_once('includes/sidebar.php');?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Donation</li>
			</ol>
		</div><!--/.row-->
        <div class="row">
			<div class="col-lg-12">
			
				
				
				<div class="panel panel-default">
					<div class="panel-heading">Donation</div>
					<div class="panel-body">
						<p style="font-size:16px; color:red" align="center"> <?php if($msg){
    echo $msg;
  }  ?> </p>
						<div class="col-md-12">
							
							<form role="form" method="post" action="">
								<div class="form-group">
									<label>Name of Donation</label>
									<input type="text" class="form-control" value="" name="name" required="true">
								</div>
                                <div class="form-group">
									<label>Amount</label>
                                    <input type="text" class="form-control" name="amount" value="" required="true">
								</div>
								<div class="form-group">
									<label>Description</label>
									<input type="text" class="form-control" name="description" value="" required="true">
								</div>
								
								<div class="form-group">
									<label>Date of Donation</label>
									<input class="form-control" type="date" value="" name="notedate" required="true">
								</div>
																
								<div class="form-group has-success">
									<button type="submit" class="btn btn-primary" name="submit">Add</button>
								</div>
								
								
								</div>
								
							</form>
						</div>
					</div>
				</div><!-- /.panel-->
			</div><!-- /.col-->
			
		</div><!-- /.row -->
	</div><!--/.main-->
    	
<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
	
</body>
</html>
<?php }  ?>