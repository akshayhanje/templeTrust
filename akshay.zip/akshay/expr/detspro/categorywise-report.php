<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (strlen($_SESSION['detsuid']) == 0) {
  header('location:logout.php');
  exit();
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>श्री १००८ भगवान पार्श्वनाथ दिगंबर जिन मंदिर</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
	<link href="css/styles.css" rel="stylesheet">

	<!-- Custom Font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

	<style>
	@media print {
		.exclude-from-print {
			display: none;
		}
	}
	</style>
</head>
<body>
	<?php include_once('includes/header.php');?>
	<?php include_once('includes/sidebar.php');?>

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row exclude-from-print">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home"></em>
				</a></li>
				<li class="active">Categorywise Expense Report</li>
			</ol>
		</div><!--/.row-->

		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading exclude-from-print">Categorywise Expense Report</div>
					<div class="panel-body">
						<div class="col-md-12">
							<form role="form" method="post" name="bwdatesreport">
								<div class="form-group exclude-from-print">
									<label>From Date</label>
									<input class="form-control" type="date" id="fromdate" name="fromdate" required="true">
								</div>
								<div class="form-group exclude-from-print">
									<label>To Date</label>
									<input class="form-control" type="date" id="todate" name="todate" required="true">
								</div>
								<div class="form-group has-success exclude-from-print">
									<button type="submit" class="btn btn-primary" name="submit">Submit</button>
								</div>
							</form>
						</div>
					</div>
				</div><!-- /.panel-->
			</div><!-- /.col-->

			<?php
			if (isset($_POST['submit'])) {
				$fdate = $_POST['fromdate'];
				$tdate = $_POST['todate'];
			?>

			<div class="col-lg-12">
			<div class="panel-heading" style="text-align:center">||श्री १००८ भगवान पार्श्वनाथ दिगंबर जिन मंदिर||</div>
				<h5 align="center" style="color: blue">Categorywise Expense Report from <?php echo $fdate;?> to <?php echo $tdate;?></h5>
				<hr />
				<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
					<thead>
						<tr>
							<th>S.NO</th>
							<th>Category</th>
							<th>Expense Amount</th>
							<th>Date</th>
						</tr>
					</thead>

					<tbody>
						<?php
						$userid = $_SESSION['detsuid'];
						$ret = mysqli_query($con, "SELECT CategoryName, SUM(ExpenseCost) AS totalexpense, DATE(ExpenseDate) AS Dateexpense FROM tblexpense WHERE (DATE(ExpenseDate) BETWEEN '$fdate' AND '$tdate') AND (UserId='$userid') GROUP BY CategoryName");
						$cnt = 1;
						$totalsexp = 0;
						while ($row = mysqli_fetch_array($ret)) {
							$categoryName = $row['CategoryName'];
							$expenseCost = $row['totalexpense'];
							$expenseDate = $row['Dateexpense'];
							$totalsexp += $expenseCost;
						?>
						<tr>
							<td><?php echo $cnt;?></td>
							<td><?php echo $categoryName;?></td>
							<td><?php echo $expenseCost;?></td>
							<td><?php echo $expenseDate;?></td>
						</tr>
						<?php
							$cnt++;
						}?>
						<tr>
							<th colspan="2" style="text-align: right">Grand Total</th>
							<td><?php echo $totalsexp;?></td>
						</tr>
					</tbody>
				</table>
			</div>

			<div class="text-center exclude-from-print">
				<button onclick="window.print()" class="btn btn-primary">Print</button>
			</div>

			<?php } ?>
		</div><!-- /.row -->
	</div><!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>
