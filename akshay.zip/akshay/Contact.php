<!DOCTYPE html>
<html>
    <head>
        <title>Contact</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <link rel ="stylesheet" href="style.css">

    </head>
    <body id="homepage">
        <div id="container">
        <header style="position: relative;">
    <img src="./img/temple2.jpg" alt="Header Image" class="img-Header" id="Manstambha">
    <div style="position: absolute; top: 15%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
        <h1 style="color: white; text-shadow: 2px 2px 4px black;font-size: 28px;">||श्री १००८ भगवान पार्श्वनाथ दिगंबर जिन मंदिर||</h1>
    </div>
</header>
            <ul class="navmenu">
                <li class="nav-item">
                    <a class="nav-link" href="home.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Contact.php">Contact</a>
                </li>
                <li class="nav-item">
              <a class="nav-link" href="./expr/detspro/index.php">Dashboard</a>
            </li>
            </ul>
        </div>
        <div class="contact">
            <div class="info">
                <h3>Contact Us</h3>
              <p>Address: 123 Main Street, Anytown USA</p>
              <p>Phone: (123) 456-7890</p>
              <p>Email: info@example.com</p>
            </div>
            <img src="./img/jain1.jpg" alt="Image Description" width="400" height="250">
          </div>
                   
    </body>
</html>

